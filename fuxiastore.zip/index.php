<?php 
session_start();
require_once "app/controllers/AppController.php";
AppController::main();
?>