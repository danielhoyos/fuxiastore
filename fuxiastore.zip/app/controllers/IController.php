<?php

interface IController {
    public function index();
}