<?php

class Configuraciones{
    
}