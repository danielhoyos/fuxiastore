<?php

class Contabilidad{
    
}
