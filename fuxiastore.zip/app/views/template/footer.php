<footer id="footer">
    <div id="pie_pagina">
        <div id="texto-L">
            <span class="icon-mail2">  </span><label>Fuxia Store ® Todos Los Derechos Reservados</label>
        </div>
        
        <div  id="texto-R">
            <p> Copyright © SOFTI COLOMBIA</p>
        </div>
        
        <div id="imagenFooter" onclick="location.href='<?php echo $config->get("rootHTTP")."index.php" ?>'">
            <span class="icon-shop"></span>
        </div>
    </div>
</footer>